# labellerr/exceptions.py

class LabellerrError(Exception):
    """Custom exception for Labellerr SDK errors."""
    pass

